# if you are running the script not on BMLL server, make sure you don't import
# modules from bmllData.data.dataProcessor and bmllData.data.utils

from bmllData.bar.timeBar import timeBar
from bmllData.bar.utils import milli_int_to_ts_str
from bmllData.bar.barBatchData import barBatchData
from Feature_BMLL.feature_cal_supporting import *

from collections import deque
import numpy as np
import warnings
import emd
from scipy.stats import skew, kurtosis

class lyao_l1_trade_nos_method3_calculate(timeBar):
    
    def __init__(
        self, 
        # first positional argument must be l1_trade_data in order to run in 
        # barBatchData for this feature (since it only use l1 trade data)
        l1_trade_data: list,
        lookback_bar_size = 30*int(1e3), # time bar size in milliseconds
        stepforward_bar_size = 30*int(1e3), # time bar move forward size
        ) -> None:    

        # init values used to calculate features
        self.book = {}
        self.co = {}

        # set featureFrame params
        self.feature_names = ['Date', 'Time', 'sk1', 'sk2', 'sk3', 'ku1', 'ku2', 'ku3', 'sk_ku1', 'sk_ku2', 'sk_ku3']
        self.cross_bar_fnames = []
        
        # Initialize book and co dictionary
        for i in range(len(self.feature_names)):
            self.co[self.feature_names[i]] = i
        for i in range(len(self.cross_bar_fnames)):
            self.book[self.cross_bar_fnames[i]] = []
        
        self.lookback_bar_size = lookback_bar_size        # bar size
        self.stepforward_bar_size = stepforward_bar_size  # bar moveforward size   

        # initiation of super class
        super().__init__(
            feature_names = self.feature_names, 
            l1_trade_data = l1_trade_data, 
            lookback_bar_size = self.lookback_bar_size, 
            stepforward_bar_size = self.stepforward_bar_size, 
            )

    # overriding parent's calc_bar_features method
    def calc_bar_features(
        self, 
        l1_trades_rows_bucket=deque([]), l1_quote_rows_bucket=deque([]),
        l3_data_rows_bucket=deque([])
        ):
        
        flag = False # flag to check if there is the first trade in the bucket

        row = [np.nan for _ in self.feature_names]
        row[self.co['Date']] = l1_trades_rows_bucket[-1][self.cDate_l1_trade]
        row[self.co['Time']] = milli_int_to_ts_str(self.milli_ts_bar_end)

        # if there is less than two trade, return nan
        if len(l1_trades_rows_bucket) > 2:
            
            ts = np.array([rec_[self.cPrice_l1_trade] for rec_ in l1_trades_rows_bucket])
            
            with warnings.catch_warnings():
                
                warnings.simplefilter("ignore")
                imf = emd.sift.sift(ts, max_imfs=4)
                
                n1 = imf[:, 0]
                sk1 = skew(n1)
                ku1 = kurtosis(n1)
                sk_ku1 = sk1 * ku1
                row[self.co['sk1']] = sk1
                row[self.co['ku1']] = ku1
                row[self.co['sk_ku1']] = sk_ku1
                
                for n_imf in range(1, min(imf.shape[1],3)): 
                    n = n1 + imf[:, n_imf]
                    n1 = n
                    row[self.co['sk'+str(n_imf+1)]] = skew(n)
                    row[self.co['ku'+str(n_imf+1)]] = kurtosis(n)
                    row[self.co['sk_ku'+str(n_imf+1)]] = skew(n)*kurtosis(n)
                    
        return row

    # overwrite parent's copy_bar method
    def copy_bar(self, prev_bar):
        
        row = [0] * len(self.feature_names)

        row[self.co['Date']] = prev_bar[self.co['Date']]
        row[self.co['Time']] = milli_int_to_ts_str(self.milli_ts_bar_end)
        
        for ft in self.feature_names[2:]: 
            row[self.co[ft]] = prev_bar[self.co[ft]] 
        # row = self._calc_cross_bars_features(row)
        return row 
    
    
if __name__ == '__main__':

    ticker = 'AAL'
    start_date = '20160104'
    end_date = '20160105'

    # for only calculating one feature of the example, we only need l1 quote
    l1_trade = True
    l1_quote = False
    l3 = False

    # the data is already in the local server, so don't need to download from
    # sftp
    download_data_from_sftp = False

    # current running script environment is local server
    compute_in_local_server = True

    batchData = barBatchData(
            ticker=ticker, start_date=start_date, end_date=end_date, 
            compute_in_local_server=compute_in_local_server,
            l1_trade=l1_trade, l1_quote=l1_quote, l3=l3,
            download_data_from_sftp=download_data_from_sftp,
        )
    
    batchData.generate_features(
        lyao_l1_trade_nos_method3_calculate,
        use_l1_trade_data=l1_trade, use_l1_quote_data=l1_quote, use_l3_data=l3,
        start_date=start_date, end_date=end_date,
    )

    bar_sub_class_name = lyao_l1_trade_nos_method3_calculate.__name__

    # first bar value is nan due to best_bid_price and best_ask_price records
    # in the first bar contains nan value
    # batchData.output[bar_sub_class_name][start_date]
    
    df = pd.DataFrame(batchData.output[bar_sub_class_name][start_date][1:], 
                  columns = batchData.output[bar_sub_class_name][start_date][0])
    df