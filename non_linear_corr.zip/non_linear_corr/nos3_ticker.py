# need input tickers 

from feature_test_funs import * 
from feature_nos_method3_calculation.lyao_feature_nos_method3_calculation_v1 import *

from bmllData.bar.timeBar import timeBar
from bmllData.bar.utils import milli_int_to_ts_str
from bmllData.bar.barBatchData import barBatchData

from collections import deque
from copy import deepcopy

from joblib import Parallel, delayed
import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import time
from tqdm import tqdm
import pickle

pd.set_option('display.width', 200)

result = {}


l1_trade = True
l1_quote = False
l3 = False

download_data_from_sftp = False
compute_in_local_server = True
lookback_bar_size = 1800 * int(1e3)
stepforward_bar_size = 30 * int(1e3)

kwargs = {'lookback_bar_size': lookback_bar_size,
        'stepforward_bar_size' : stepforward_bar_size,
        } # add kwargs for feature class here

feature_class = lyao_l1_trade_nos_method3_calculate

dates = pd.date_range(start = '20160101', end = '20201231')

fret_time = 30 * 60 * int(1e3)
fret_n_bars = fret_time // stepforward_bar_size
n_jobs = 100


def input_tickers(tickers):
    
    print(tickers)
    ticker_name = tickers[0]
    print( '20160110')
    tickers = tickers
    
    feature_dfs, corr_mats, corr_with_fret, target_dict = process_tickers(tickers, l1_trade, l1_quote, l3, download_data_from_sftp,
                                                            compute_in_local_server, kwargs, feature_class, dates,
                                                            fret_n_bars, n_jobs)

    # feature = pd.concat(feature_dfs, axis=0)


    # result['feature_na'] = feature.isna().sum()
    # result['feature_describe'] = feature.describe()
    # result['feature_corr'] = feature.corr(numeric_only=True)

    # for i in ['sk1', 'sk2', 'sk3', 'ku1', 'ku2', 'ku3', 'sk_ku1', 'sk_ku2', 'sk_ku3']: 
    #     feature[i].dropna().plot()
    #     plt.title('lyao_feature_nos_method3_calculation: ' + i)
    #     plt.savefig('lyao_feature_nos_method3_calculation_' + i + '.png')
    #     plt.close()

    # res_df1 = pd.concat(target_dict, axis=0)
    # t3 = pd.read_parquet("/data/target_agg/TimeBar-30-start_20151027-end_20201231-M1-780_M2-10/ticker_universe_56_overnight_False_future_64_bars_mid.parquet.gzip")
    # new_corr = pd.concat([res_df1, t3], axis=1, join='inner')
    # new_corr_mat = new_corr.corr(numeric_only=True)
    # result['feature_targer_corr'] = new_corr_mat 

    # for i in ['sk1', 'sk2', 'sk3', 'ku1', 'ku2', 'ku3', 'sk_ku1', 'sk_ku2', 'sk_ku3']: 
    #     plt.scatter(new_corr[i], new_corr['pred'], s = 1)
    #     plt.xlabel('feature: ' + i)
    #     plt.ylabel('target')
    #     plt.title('scatter plot: target v.s.' + i)
    #     plt.savefig('lyao_feature_nos_method3_calculation_scatter_' + i + '.png')
    #     plt.close()

    with open('lyao_feature_nos_method3_calculation_test_v1_' + ticker_name + '.pkl', 'wb') as f:
        pickle.dump(feature_dfs, f)